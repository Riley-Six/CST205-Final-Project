Project Name: CST-205-Final-Project
Team Members: Riley Galloway, Eric Guerra, Pedro Avalos
Class: CST205-01_FA20:Multimedia Design & Progmng
Date: 12/2/2020
Instructions:   Run dummy.py, type in name and search
                Imports:    pip install Google-Images-Search
                            pip install windows-curses
                            (May need other imports if you are not a members of CST 205)
                            
Design Doc: https://docs.google.com/document/d/1fpNj7yo4SOnQPV4L-6TwV7HHD22LeQgNBT29MaIu2AM/edit?usp=sharing&resourcekey=0-RprPWSgDnLFyCuYHkty-rA
Github Repo: https://github.com/Riley-Six/CST205-Final-Project
Trello: https://trello.com/b/BWDJ8Tc2/jobs
Future Work: Optimize image storage, HTML enhancing
